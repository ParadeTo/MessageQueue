package com.paradeto.entity

/**
 * Created by Ayou on 2015/11/9.
 */
case class Area (val area:String,val count:Int)
