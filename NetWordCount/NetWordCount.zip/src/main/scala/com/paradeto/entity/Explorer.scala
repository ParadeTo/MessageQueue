package com.paradeto.entity

/**
 * Created by Ayou on 2015/11/9.
 */
case class Explorer (val explorer:String,val count:Int)
