package com.paradeto.entity

/**
 * Created by Ayou on 2015/11/9.
 */
case class PV (val page:String,val count:Int)
