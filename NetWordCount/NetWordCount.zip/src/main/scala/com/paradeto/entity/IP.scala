package com.paradeto.entity

/**
 * Created by Ayou on 2015/11/9.
 */
case class IP(val ip:String,val count:Int)
